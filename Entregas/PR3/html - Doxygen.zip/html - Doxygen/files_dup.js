var files_dup =
[
    [ "AVL.cpp", "_a_v_l_8cpp.html", null ],
    [ "AVL.h", "_a_v_l_8h.html", [
      [ "AVL< T >", "class_a_v_l.html", "class_a_v_l" ]
    ] ],
    [ "Etiqueta.cpp", "_etiqueta_8cpp.html", null ],
    [ "Etiqueta.h", "_etiqueta_8h.html", [
      [ "Etiqueta", "class_etiqueta.html", "class_etiqueta" ]
    ] ],
    [ "fecha.cpp", "fecha_8cpp.html", "fecha_8cpp" ],
    [ "fecha.h", "fecha_8h.html", "fecha_8h" ],
    [ "ImageBook.cpp", "_image_book_8cpp.html", null ],
    [ "ImageBook.h", "_image_book_8h.html", [
      [ "ImageBook", "class_image_book.html", "class_image_book" ]
    ] ],
    [ "Imagen.cpp", "_imagen_8cpp.html", null ],
    [ "Imagen.h", "_imagen_8h.html", [
      [ "Imagen", "class_imagen.html", "class_imagen" ]
    ] ],
    [ "Iterador.cpp", "_iterador_8cpp.html", null ],
    [ "Iterador.h", "_iterador_8h.html", [
      [ "Iterador< T >", "class_iterador.html", "class_iterador" ]
    ] ],
    [ "ListaDEnlazada.cpp", "_lista_d_enlazada_8cpp.html", null ],
    [ "ListaDEnlazada.h", "_lista_d_enlazada_8h.html", [
      [ "ListaDEnlazada< T >", "class_lista_d_enlazada.html", "class_lista_d_enlazada" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Nodo.cpp", "_nodo_8cpp.html", null ],
    [ "Nodo.h", "_nodo_8h.html", [
      [ "Nodo< T >", "class_nodo.html", "class_nodo" ]
    ] ],
    [ "NodoAVL.cpp", "_nodo_a_v_l_8cpp.html", null ],
    [ "NodoAVL.h", "_nodo_a_v_l_8h.html", [
      [ "NodoAVL< T >", "class_nodo_a_v_l.html", "class_nodo_a_v_l" ]
    ] ],
    [ "Usuario.cpp", "_usuario_8cpp.html", null ],
    [ "Usuario.h", "_usuario_8h.html", [
      [ "Usuario", "class_usuario.html", "class_usuario" ]
    ] ],
    [ "VDinamico.cpp", "_v_dinamico_8cpp.html", null ],
    [ "VDinamico.h", "_v_dinamico_8h.html", [
      [ "VDinamico< T >", "class_v_dinamico.html", "class_v_dinamico" ]
    ] ]
];