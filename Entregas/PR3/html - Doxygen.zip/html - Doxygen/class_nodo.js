var class_nodo =
[
    [ "Nodo", "class_nodo.html#aeefb2e4bd278e870e791d40c98bedd4c", null ],
    [ "Nodo", "class_nodo.html#a4582b0c1f6f167ed48e6607a0b51dc9f", null ],
    [ "~Nodo", "class_nodo.html#af6c6a081aa52d669565c2ba19a4dd49b", null ],
    [ "getAnt", "class_nodo.html#a511dd73808a3187ea95a32c9fc4c6da9", null ],
    [ "getDato", "class_nodo.html#a21d3d44abf6b07a8533a80bce57cec6a", null ],
    [ "getSig", "class_nodo.html#a5fd93f4e41580e20f58f19c6e117714d", null ],
    [ "nullAntSig", "class_nodo.html#a70cda9181e812501835261b63c2108f2", null ],
    [ "setAnt", "class_nodo.html#afc854a292895271c58b0cd51bf554e22", null ],
    [ "setAntSig", "class_nodo.html#ab75812bad9ddc43a849fa252031138af", null ],
    [ "setDato", "class_nodo.html#a989a760f05e5f395496bd997ea41f29b", null ],
    [ "setSig", "class_nodo.html#ae801fe80f8ce0f27a23bb4cd97899e31", null ],
    [ "ant", "class_nodo.html#ae90e8ffbffa6473280c66c17a8ce2d78", null ],
    [ "dato", "class_nodo.html#ad2db7dbf78e797a2c4f4541619245d4f", null ],
    [ "sig", "class_nodo.html#a91ef988790cba2200452f28cf0446712", null ]
];