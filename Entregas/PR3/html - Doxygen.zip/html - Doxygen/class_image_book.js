var class_image_book =
[
    [ "ImageBook", "class_image_book.html#a46f43e82ada3fce2ba201d03a2671c3d", null ],
    [ "ImageBook", "class_image_book.html#ab972f7ba362fb943eba596fb55bf24ee", null ],
    [ "~ImageBook", "class_image_book.html#a99b7fc1abc31799360b5bb404f6adef4", null ],
    [ "buscarUsuario", "class_image_book.html#a55b8bc98313ecba5604fab123b1e0240", null ],
    [ "buscarUsuarioEtiq", "class_image_book.html#ab7dc6a08bf4dd1fa4c61371652781ce8", null ],
    [ "cargarFicheros", "class_image_book.html#addb865298acdd23b0cdcf5c521927a68", null ],
    [ "getMasActivos", "class_image_book.html#a58265a6fa5bd7ccf96712e4b03237eab", null ],
    [ "mostrarEstado", "class_image_book.html#a84a2fc0ffc524eb7b6050db7371c2871", null ]
];