var annotated_dup =
[
    [ "AVL", "class_a_v_l.html", "class_a_v_l" ],
    [ "ErrorFechaIncorrecta", "class_error_fecha_incorrecta.html", null ],
    [ "Etiqueta", "class_etiqueta.html", "class_etiqueta" ],
    [ "Fecha", "class_fecha.html", "class_fecha" ],
    [ "ImageBook", "class_image_book.html", "class_image_book" ],
    [ "Imagen", "class_imagen.html", "class_imagen" ],
    [ "Iterador", "class_iterador.html", "class_iterador" ],
    [ "ListaDEnlazada", "class_lista_d_enlazada.html", "class_lista_d_enlazada" ],
    [ "Nodo", "class_nodo.html", "class_nodo" ],
    [ "NodoAVL", "class_nodo_a_v_l.html", "class_nodo_a_v_l" ],
    [ "Usuario", "class_usuario.html", "class_usuario" ],
    [ "VDinamico", "class_v_dinamico.html", "class_v_dinamico" ]
];