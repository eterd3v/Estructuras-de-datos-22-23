var class_iterador =
[
    [ "Iterador", "class_iterador.html#a95667696efab8089c63826a5fe3d23bc", null ],
    [ "Iterador", "class_iterador.html#ab9539d5cae5911f94183dc3a5eb8661b", null ],
    [ "anterior", "class_iterador.html#a4fa88fd53fce632d9eaaca504003e7c3", null ],
    [ "dato", "class_iterador.html#a847bc22055e6d52f7894411e4ac70383", null ],
    [ "hayAnterior", "class_iterador.html#a3ae92303b37e4445c81879114e6e10cd", null ],
    [ "haySiguiente", "class_iterador.html#a42c3f8b0cec7c86a4874130df1de9892", null ],
    [ "operator=", "class_iterador.html#a2a9893ad98938a257b53ff3849d63e4b", null ],
    [ "siguiente", "class_iterador.html#a3437fb728fcaacc2bd9e3685ebd2b784", null ],
    [ "ListaDEnlazada< T >", "class_iterador.html#a11380f50529fcc83cc57e900cd3a091b", null ]
];