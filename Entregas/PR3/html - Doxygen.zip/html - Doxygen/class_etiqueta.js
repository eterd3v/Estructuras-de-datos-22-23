var class_etiqueta =
[
    [ "Etiqueta", "class_etiqueta.html#aaf0b9fe57ea31a58b0dc4012cf8198a2", null ],
    [ "Etiqueta", "class_etiqueta.html#ac48f84d8f47bff0faadc1f954b4fdf67", null ],
    [ "~Etiqueta", "class_etiqueta.html#a4cd002555e16fd6f49ffd8a6ba13808a", null ],
    [ "getNombre", "class_etiqueta.html#aec549101179d8aca2d1a0bba2b36d689", null ],
    [ "operator!=", "class_etiqueta.html#a9295b0b7124b521bc0b70a87ecbd10bb", null ],
    [ "operator==", "class_etiqueta.html#aa4b901635ca2a8d492b20c764200f301", null ],
    [ "setNombre", "class_etiqueta.html#a176c48e6e82acce0f502db80cf60f741", null ]
];