var searchData=
[
  ['dato_0',['dato',['../class_iterador.html#a847bc22055e6d52f7894411e4ac70383',1,'Iterador']]]
];
