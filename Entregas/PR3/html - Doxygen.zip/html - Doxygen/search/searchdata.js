var indexSectionsWithContent =
{
  0: "abcdefghilmnorstuv~",
  1: "aefilnuv",
  2: "s",
  3: "aefilmnuv",
  4: "abcdefghilmnorstuv~",
  5: "abdis",
  6: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends"
};

