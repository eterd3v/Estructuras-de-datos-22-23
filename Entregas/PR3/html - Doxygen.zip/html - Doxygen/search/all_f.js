var searchData=
[
  ['tamlog_0',['tamlog',['../class_v_dinamico.html#a6116f41cab791ccfa3fd98c0d78274ec',1,'VDinamico']]],
  ['to_5fstring_1',['to_string',['../class_imagen.html#a28c2cdb49b4cc9f1fd7bef5faff37f99',1,'Imagen']]]
];
