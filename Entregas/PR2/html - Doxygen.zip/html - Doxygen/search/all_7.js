var searchData=
[
  ['hayanterior_0',['hayAnterior',['../class_iterador.html#a3ae92303b37e4445c81879114e6e10cd',1,'Iterador']]],
  ['haysiguiente_1',['haySiguiente',['../class_iterador.html#a42c3f8b0cec7c86a4874130df1de9892',1,'Iterador']]]
];
