var searchData=
[
  ['etiqmasrepetida_0',['etiqMasRepetida',['../class_image_book.html#a4125ec69ad4ab578c8c66de0b8bd7a02',1,'ImageBook']]],
  ['etiqueta_1',['Etiqueta',['../class_etiqueta.html#aaf0b9fe57ea31a58b0dc4012cf8198a2',1,'Etiqueta::Etiqueta()'],['../class_etiqueta.html#ac48f84d8f47bff0faadc1f954b4fdf67',1,'Etiqueta::Etiqueta(const string &amp;nombre)']]]
];
