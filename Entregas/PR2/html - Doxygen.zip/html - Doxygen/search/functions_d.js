var searchData=
[
  ['setant_0',['setAnt',['../class_nodo.html#afc854a292895271c58b0cd51bf554e22',1,'Nodo']]],
  ['setantsig_1',['setAntSig',['../class_nodo.html#ab75812bad9ddc43a849fa252031138af',1,'Nodo']]],
  ['setdato_2',['setDato',['../class_nodo.html#a989a760f05e5f395496bd997ea41f29b',1,'Nodo']]],
  ['setemail_3',['setEmail',['../class_imagen.html#a7e6ef70712cfe00999a06594fb6f6d32',1,'Imagen']]],
  ['setetiqueta_4',['setEtiqueta',['../class_imagen.html#a7dcb440b36bfdb9407f710440e4a2aee',1,'Imagen']]],
  ['setfecha_5',['setFecha',['../class_imagen.html#a204a2f9665282a6645271493ea319728',1,'Imagen']]],
  ['setid_6',['setId',['../class_imagen.html#ace76613f7d8c7ae249df5c23b32179b6',1,'Imagen']]],
  ['setnombre_7',['setNombre',['../class_etiqueta.html#a176c48e6e82acce0f502db80cf60f741',1,'Etiqueta::setNombre()'],['../class_imagen.html#aa97acfda107dd7e13dd0a5447f4eba3d',1,'Imagen::setNombre()']]],
  ['setsig_8',['setSig',['../class_nodo.html#ae801fe80f8ce0f27a23bb4cd97899e31',1,'Nodo']]],
  ['settam_9',['setTam',['../class_imagen.html#a0d83e46f4b087f75aebc89ec653622c2',1,'Imagen']]],
  ['siguiente_10',['siguiente',['../class_iterador.html#a3437fb728fcaacc2bd9e3685ebd2b784',1,'Iterador']]]
];
