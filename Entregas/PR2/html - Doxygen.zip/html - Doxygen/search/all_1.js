var searchData=
[
  ['borra_0',['borra',['../class_lista_d_enlazada.html#a75f449f67ecec7e70feb1d110d0b22e0',1,'ListaDEnlazada']]],
  ['borrar_1',['borrar',['../class_v_dinamico.html#a44c4a73439f1e5f1275c5a43a93d3964',1,'VDinamico']]],
  ['borrarfinal_2',['borrarFinal',['../class_lista_d_enlazada.html#a4a06ec4907a602f40c6548bdb8e6de44',1,'ListaDEnlazada']]],
  ['borrarinicio_3',['borrarInicio',['../class_lista_d_enlazada.html#a1ce300987e03412f985683a2cba55477',1,'ListaDEnlazada']]],
  ['buscarimgetq_4',['buscarImgEtq',['../class_image_book.html#a22102521541cdaf0dd40d1c637d17a2c',1,'ImageBook']]],
  ['busquedabin_5',['busquedaBin',['../class_v_dinamico.html#aab28aa691171027aa74e9ad89f8083b8',1,'VDinamico']]]
];
