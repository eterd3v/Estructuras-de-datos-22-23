var searchData=
[
  ['nodo_0',['Nodo',['../class_nodo.html#aeefb2e4bd278e870e791d40c98bedd4c',1,'Nodo::Nodo()'],['../class_nodo.html#a4582b0c1f6f167ed48e6607a0b51dc9f',1,'Nodo::Nodo(T &amp;dato, Nodo&lt; T &gt; *nodoAnt=nullptr, Nodo&lt; T &gt; *nodoSig=nullptr)']]],
  ['nullantsig_1',['nullAntSig',['../class_nodo.html#a70cda9181e812501835261b63c2108f2',1,'Nodo']]]
];
