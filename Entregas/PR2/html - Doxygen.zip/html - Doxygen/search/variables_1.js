var searchData=
[
  ['dato_0',['dato',['../class_nodo.html#ad2db7dbf78e797a2c4f4541619245d4f',1,'Nodo']]]
];
