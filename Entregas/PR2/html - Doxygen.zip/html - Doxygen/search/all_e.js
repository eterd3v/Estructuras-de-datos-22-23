var searchData=
[
  ['tamlog_0',['tamlog',['../class_v_dinamico.html#a0ea434c0396f88a7053217e80cecf029',1,'VDinamico']]],
  ['to_5fstring_1',['to_string',['../class_imagen.html#a28c2cdb49b4cc9f1fd7bef5faff37f99',1,'Imagen']]]
];
