var structelem =
[
    [ "est", "structelem.html#a1b8abe5381ccdb21b21776a96146217f", null ],
    [ "img", "structelem.html#ae12bf05d9024c622a3242a33f04d33f0", null ]
];