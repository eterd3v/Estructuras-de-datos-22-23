var files_dup =
[
    [ "Etiqueta.cpp", "_etiqueta_8cpp.html", null ],
    [ "Etiqueta.h", "_etiqueta_8h.html", [
      [ "Etiqueta", "class_etiqueta.html", "class_etiqueta" ]
    ] ],
    [ "fecha.cpp", "fecha_8cpp.html", "fecha_8cpp" ],
    [ "fecha.h", "fecha_8h.html", "fecha_8h" ],
    [ "ImageBook.cpp", "_image_book_8cpp.html", null ],
    [ "ImageBook.h", "_image_book_8h.html", [
      [ "ImageBook", "class_image_book.html", "class_image_book" ]
    ] ],
    [ "Imagen.cpp", "_imagen_8cpp.html", null ],
    [ "Imagen.h", "_imagen_8h.html", [
      [ "Imagen", "class_imagen.html", "class_imagen" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "THashImagen.cpp", "_t_hash_imagen_8cpp.html", null ],
    [ "THashImagen.h", "_t_hash_imagen_8h.html", "_t_hash_imagen_8h" ],
    [ "Usuario.cpp", "_usuario_8cpp.html", null ],
    [ "Usuario.h", "_usuario_8h.html", [
      [ "Usuario", "class_usuario.html", "class_usuario" ]
    ] ]
];