var class_image_book =
[
    [ "ImageBook", "class_image_book.html#a46f43e82ada3fce2ba201d03a2671c3d", null ],
    [ "ImageBook", "class_image_book.html#ab972f7ba362fb943eba596fb55bf24ee", null ],
    [ "~ImageBook", "class_image_book.html#a99b7fc1abc31799360b5bb404f6adef4", null ],
    [ "borrarImagen", "class_image_book.html#a1081259e18bf1e93ad7d1992bd936ca5", null ],
    [ "buscarEtiqueta", "class_image_book.html#aa5996834964caf7a532719f2c6d2717d", null ],
    [ "buscarImagen", "class_image_book.html#aa0ddd0b46be6813d0b4b9350451f1a47", null ],
    [ "buscarImagEtiq", "class_image_book.html#a51b518d582767a1a286c020641117766", null ],
    [ "buscarMiEtiqueta", "class_image_book.html#ad2b73414f0432c4ffe9723e2ef33b50b", null ],
    [ "buscarUsuario", "class_image_book.html#a55b8bc98313ecba5604fab123b1e0240", null ],
    [ "buscarUsuarioEtiq", "class_image_book.html#aabacd76b211965fab12fd0a4b7772d17", null ],
    [ "buscarUsuarioFechaImagen", "class_image_book.html#a5d67326d4725f71effc619872fd1ec64", null ],
    [ "cargar", "class_image_book.html#ab72e21122795781a67877812eb04576f", null ],
    [ "consultarImagenes", "class_image_book.html#a7fbed5abb6c05fab08bb6940ddaa4cf4", null ],
    [ "getMasActivos", "class_image_book.html#a6e1b383a93757e38bb8feba59e58b5a1", null ],
    [ "getMasLikes", "class_image_book.html#a87127650acb308fd81d230d6d2255f8b", null ],
    [ "getMasPopulares", "class_image_book.html#abebc4523169a74cdd98e15d4d854c51f", null ],
    [ "insertarImagen", "class_image_book.html#a6bca9d6e1874d041a3d12168c78003cd", null ],
    [ "mostrarEstado", "class_image_book.html#a84a2fc0ffc524eb7b6050db7371c2871", null ]
];