var _t_hash_imagen_8h =
[
    [ "elem", "structelem.html", "structelem" ],
    [ "THashImagen", "class_t_hash_imagen.html", "class_t_hash_imagen" ],
    [ "estado", "_t_hash_imagen_8h.html#a6d66b110c5c28df3807c8428061e047e", [
      [ "vacio", "_t_hash_imagen_8h.html#a6d66b110c5c28df3807c8428061e047eaec4e0163b37d0098f59f45ec2d99d44e", null ],
      [ "eliminado", "_t_hash_imagen_8h.html#a6d66b110c5c28df3807c8428061e047ea8ecc62f94fdb289070dfd712d590b4c2", null ],
      [ "ocupado", "_t_hash_imagen_8h.html#a6d66b110c5c28df3807c8428061e047ea93ab32b3122713a8d3959173c0af550b", null ]
    ] ]
];