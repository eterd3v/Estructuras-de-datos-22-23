var annotated_dup =
[
    [ "elem", "structelem.html", "structelem" ],
    [ "ErrorFechaIncorrecta", "class_error_fecha_incorrecta.html", null ],
    [ "Etiqueta", "class_etiqueta.html", "class_etiqueta" ],
    [ "Fecha", "class_fecha.html", "class_fecha" ],
    [ "ImageBook", "class_image_book.html", "class_image_book" ],
    [ "Imagen", "class_imagen.html", "class_imagen" ],
    [ "THashImagen", "class_t_hash_imagen.html", "class_t_hash_imagen" ],
    [ "Usuario", "class_usuario.html", "class_usuario" ]
];