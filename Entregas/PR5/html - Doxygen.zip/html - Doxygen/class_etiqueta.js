var class_etiqueta =
[
    [ "Etiqueta", "class_etiqueta.html#aaf0b9fe57ea31a58b0dc4012cf8198a2", null ],
    [ "Etiqueta", "class_etiqueta.html#a6fbe33d56b31737bcb56679fdc2c28b1", null ],
    [ "Etiqueta", "class_etiqueta.html#aee7a9c4515df8c5ad138c5eee80afb37", null ],
    [ "~Etiqueta", "class_etiqueta.html#a4cd002555e16fd6f49ffd8a6ba13808a", null ],
    [ "getImages", "class_etiqueta.html#ab880abbb66523b173e599b7effc48ce3", null ],
    [ "getNombre", "class_etiqueta.html#aec549101179d8aca2d1a0bba2b36d689", null ],
    [ "getTotalLikes", "class_etiqueta.html#a76549f2e85a595e7e5d755172a56596d", null ],
    [ "nuevaImagen", "class_etiqueta.html#abc554b9020aa209a51b10dec7030f0e8", null ],
    [ "operator!=", "class_etiqueta.html#a9295b0b7124b521bc0b70a87ecbd10bb", null ],
    [ "operator==", "class_etiqueta.html#aa4b901635ca2a8d492b20c764200f301", null ],
    [ "setNombre", "class_etiqueta.html#a176c48e6e82acce0f502db80cf60f741", null ]
];