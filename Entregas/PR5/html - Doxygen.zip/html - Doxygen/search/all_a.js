var searchData=
[
  ['nuevaimagen_0',['nuevaImagen',['../class_etiqueta.html#abc554b9020aa209a51b10dec7030f0e8',1,'Etiqueta']]],
  ['nuevolike_1',['nuevoLike',['../class_imagen.html#a6dbf60f76988b2f2c4f5abcc763f8881',1,'Imagen']]],
  ['numejercicio_2',['numEjercicio',['../main_8cpp.html#aa6012ae1f1720c345aea0723e4173ce6',1,'main.cpp']]],
  ['numimages_3',['numImages',['../class_t_hash_imagen.html#a73360d9ae4604985d418f5492a481dc9',1,'THashImagen']]],
  ['nummax10_4',['numMax10',['../class_t_hash_imagen.html#a5ac349d28cd526f07b60ef90cf006abe',1,'THashImagen']]]
];
