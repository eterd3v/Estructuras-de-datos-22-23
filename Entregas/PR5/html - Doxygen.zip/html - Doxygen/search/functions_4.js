var searchData=
[
  ['etiqueta_0',['Etiqueta',['../class_etiqueta.html#aaf0b9fe57ea31a58b0dc4012cf8198a2',1,'Etiqueta::Etiqueta()'],['../class_etiqueta.html#a6fbe33d56b31737bcb56679fdc2c28b1',1,'Etiqueta::Etiqueta(const string &amp;nombre, const list&lt; Imagen * &gt; &amp;etiImagen)'],['../class_etiqueta.html#aee7a9c4515df8c5ad138c5eee80afb37',1,'Etiqueta::Etiqueta(const Etiqueta &amp;orig)']]]
];
