var searchData=
[
  ['likeautomatico_0',['likeAutomatico',['../class_usuario.html#aa96d64ddcdfd8213444b6de645fe6cb8',1,'Usuario']]]
];
