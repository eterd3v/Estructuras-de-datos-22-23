var searchData=
[
  ['setemail_0',['setEmail',['../class_usuario.html#adfbec40a5a6fa1f495c714ad4e46d0ca',1,'Usuario']]],
  ['setfecha_1',['setFecha',['../class_imagen.html#a204a2f9665282a6645271493ea319728',1,'Imagen']]],
  ['setib_2',['setIb',['../class_usuario.html#aed97537dd51f98af3308ee6476616bfb',1,'Usuario']]],
  ['setid_3',['setId',['../class_imagen.html#ace76613f7d8c7ae249df5c23b32179b6',1,'Imagen']]],
  ['setlikes_4',['setLikes',['../class_imagen.html#a423e6b769f990358c684e634ff656dfd',1,'Imagen']]],
  ['setnombre_5',['setNombre',['../class_etiqueta.html#a176c48e6e82acce0f502db80cf60f741',1,'Etiqueta::setNombre()'],['../class_imagen.html#aa97acfda107dd7e13dd0a5447f4eba3d',1,'Imagen::setNombre()']]],
  ['setpopularidad_6',['setPopularidad',['../class_usuario.html#aed44d73e9fcc226c5cf2f00600c20ae5',1,'Usuario']]],
  ['settam_7',['setTam',['../class_imagen.html#a0d83e46f4b087f75aebc89ec653622c2',1,'Imagen']]]
];
