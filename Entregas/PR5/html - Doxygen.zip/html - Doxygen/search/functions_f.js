var searchData=
[
  ['usuario_0',['Usuario',['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()'],['../class_usuario.html#a16dc89f4efd2018ede0d5b41b7d46698',1,'Usuario::Usuario(const string &amp;email)'],['../class_usuario.html#a5b8c44d4b7d7b2e49542cda79521fffa',1,'Usuario::Usuario(const Usuario &amp;orig)']]]
];
