var searchData=
[
  ['getemail_0',['getEmail',['../class_usuario.html#af0e203835460d0e57feb525f969dc8ff',1,'Usuario']]],
  ['getetiqueta_1',['getEtiqueta',['../class_imagen.html#a342ab381a2ca6672e0496cc2494d4ffc',1,'Imagen']]],
  ['getetiquetas_2',['getEtiquetas',['../class_imagen.html#a4b673fdb962b4586ef73f68989c32d20',1,'Imagen']]],
  ['getfecha_3',['getFecha',['../class_imagen.html#a5b1aed37f369896b51765f9c4861dee2',1,'Imagen']]],
  ['getid_4',['getId',['../class_imagen.html#ada12145018eb081a5d58721622e7ee30',1,'Imagen']]],
  ['getimagenfecha_5',['getImagenFecha',['../class_usuario.html#a301ac975ecdaa151b2ec6a08135eb30c',1,'Usuario']]],
  ['getimagenmasantigua_6',['getImagenMasAntigua',['../class_usuario.html#a98db51722c298c8972422675bf215803',1,'Usuario']]],
  ['getimagenmasreciente_7',['getImagenMasReciente',['../class_usuario.html#a67dd901c5448c4562e972d78184faec5',1,'Usuario']]],
  ['getmasactivos_8',['getMasActivos',['../class_image_book.html#a6e1b383a93757e38bb8feba59e58b5a1',1,'ImageBook']]],
  ['getnombre_9',['getNombre',['../class_etiqueta.html#aec549101179d8aca2d1a0bba2b36d689',1,'Etiqueta::getNombre()'],['../class_imagen.html#af9a98fdd25386abc59ddf0494d3a911d',1,'Imagen::getNombre()']]],
  ['getnumimages_10',['getNumImages',['../class_usuario.html#a83864cff7163f3bb95fa379d992e96d4',1,'Usuario']]],
  ['gettam_11',['getTam',['../class_imagen.html#a6f977059994ec217b3fb5dc47c932a7b',1,'Imagen']]]
];
