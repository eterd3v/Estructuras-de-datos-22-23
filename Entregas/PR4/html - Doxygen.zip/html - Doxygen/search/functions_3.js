var searchData=
[
  ['etiqueta_0',['Etiqueta',['../class_etiqueta.html#aaf0b9fe57ea31a58b0dc4012cf8198a2',1,'Etiqueta::Etiqueta()'],['../class_etiqueta.html#ac48f84d8f47bff0faadc1f954b4fdf67',1,'Etiqueta::Etiqueta(const string &amp;nombre)']]]
];
