var searchData=
[
  ['setfecha_0',['setFecha',['../class_imagen.html#a204a2f9665282a6645271493ea319728',1,'Imagen']]],
  ['setib_1',['setIb',['../class_usuario.html#aed97537dd51f98af3308ee6476616bfb',1,'Usuario']]],
  ['setid_2',['setId',['../class_imagen.html#ace76613f7d8c7ae249df5c23b32179b6',1,'Imagen']]],
  ['setnombre_3',['setNombre',['../class_etiqueta.html#a176c48e6e82acce0f502db80cf60f741',1,'Etiqueta::setNombre()'],['../class_imagen.html#aa97acfda107dd7e13dd0a5447f4eba3d',1,'Imagen::setNombre(const string &amp;nombre)']]],
  ['settam_4',['setTam',['../class_imagen.html#a0d83e46f4b087f75aebc89ec653622c2',1,'Imagen']]]
];
