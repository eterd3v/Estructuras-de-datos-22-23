var searchData=
[
  ['buscaretiq_0',['buscarEtiq',['../class_usuario.html#a6f36f833d3b4b79c934986d6443b8b61',1,'Usuario']]],
  ['buscarimagen_1',['buscarImagen',['../class_usuario.html#a95c1a054f4cf69dfe4bd8d91e380dff0',1,'Usuario']]],
  ['buscarmietiqueta_2',['buscarMiEtiqueta',['../class_image_book.html#ad2b73414f0432c4ffe9723e2ef33b50b',1,'ImageBook']]],
  ['buscarusuario_3',['buscarUsuario',['../class_image_book.html#a55b8bc98313ecba5604fab123b1e0240',1,'ImageBook']]],
  ['buscarusuarioetiq_4',['buscarUsuarioEtiq',['../class_image_book.html#aabacd76b211965fab12fd0a4b7772d17',1,'ImageBook']]],
  ['buscarusuariofechaimagen_5',['buscarUsuarioFechaImagen',['../class_image_book.html#aa342d1208e83f092c12a1dd939d98cd5',1,'ImageBook']]],
  ['buscarusuariosetiq_6',['buscarUsuariosEtiq',['../class_usuario.html#af01694aaa75e677c88adc4c78018854a',1,'Usuario']]]
];
