var files_dup =
[
    [ "ContenedorImagenes.cpp", "_contenedor_imagenes_8cpp.html", null ],
    [ "ContenedorImagenes.h", "_contenedor_imagenes_8h.html", "_contenedor_imagenes_8h" ],
    [ "fecha.cpp", "fecha_8cpp.html", "fecha_8cpp" ],
    [ "fecha.h", "fecha_8h.html", "fecha_8h" ],
    [ "Imagen.cpp", "_imagen_8cpp.html", null ],
    [ "Imagen.h", "_imagen_8h.html", [
      [ "Imagen", "class_imagen.html", "class_imagen" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];