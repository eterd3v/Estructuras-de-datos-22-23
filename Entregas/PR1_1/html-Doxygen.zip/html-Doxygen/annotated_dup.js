var annotated_dup =
[
    [ "ContenedorImagenes", "class_contenedor_imagenes.html", "class_contenedor_imagenes" ],
    [ "ErrorFechaIncorrecta", "class_error_fecha_incorrecta.html", null ],
    [ "Fecha", "class_fecha.html", "class_fecha" ],
    [ "Imagen", "class_imagen.html", "class_imagen" ]
];