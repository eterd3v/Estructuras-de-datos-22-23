var _contenedor_imagenes_8h =
[
    [ "ContenedorImagenes", "class_contenedor_imagenes.html", "class_contenedor_imagenes" ],
    [ "TAM_PREDEF", "_contenedor_imagenes_8h.html#a11c11ea1ce57490d807169f319d4521e", null ]
];