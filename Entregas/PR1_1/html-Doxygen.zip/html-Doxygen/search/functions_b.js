var searchData=
[
  ['tam_0',['tam',['../class_contenedor_imagenes.html#a006a7d20568401f56eabd43ae06dac86',1,'ContenedorImagenes']]],
  ['to_5fstring_1',['to_string',['../class_imagen.html#a28c2cdb49b4cc9f1fd7bef5faff37f99',1,'Imagen']]]
];
