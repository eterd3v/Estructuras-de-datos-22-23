var searchData=
[
  ['recupera_0',['recupera',['../class_contenedor_imagenes.html#aa6c59f979e795651208b8fd3425ae4a3',1,'ContenedorImagenes']]]
];
