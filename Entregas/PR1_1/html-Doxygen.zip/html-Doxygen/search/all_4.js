var searchData=
[
  ['fecha_0',['Fecha',['../class_fecha.html',1,'Fecha'],['../class_fecha.html#a5fbc6564d9c48e73cf8d27568a2a7fc5',1,'Fecha::Fecha()'],['../class_fecha.html#a2548cec49fb9b07debabd9ee0565514f',1,'Fecha::Fecha(unsigned aDia, unsigned aMes, unsigned aAnio, unsigned aHora=0, unsigned aMin=0)'],['../class_fecha.html#a7201e00ac3fa1e07dfa124f3bd999dec',1,'Fecha::Fecha(const Fecha &amp;f)']]],
  ['fecha_2ecpp_1',['fecha.cpp',['../fecha_8cpp.html',1,'']]],
  ['fecha_2eh_2',['fecha.h',['../fecha_8h.html',1,'']]]
];
