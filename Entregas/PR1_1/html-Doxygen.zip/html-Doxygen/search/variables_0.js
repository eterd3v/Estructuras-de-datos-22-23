var searchData=
[
  ['tam_5fpredef_0',['TAM_PREDEF',['../_contenedor_imagenes_8h.html#a11c11ea1ce57490d807169f319d4521e',1,'ContenedorImagenes.h']]]
];
