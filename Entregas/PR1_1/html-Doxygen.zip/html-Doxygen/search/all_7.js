var searchData=
[
  ['localiza_0',['localiza',['../class_contenedor_imagenes.html#a65b25ad89ba177aabd8a6ab508bb327f',1,'ContenedorImagenes']]]
];
