var searchData=
[
  ['veranio_0',['verAnio',['../class_fecha.html#a0b56e2d6672bc728cf82c4e26ab7fb38',1,'Fecha']]],
  ['verdia_1',['verDia',['../class_fecha.html#a0f6a9694242181a60f6351dd031ec265',1,'Fecha']]],
  ['verhora_2',['verHora',['../class_fecha.html#a14c51421f53202110c2dd030b4d323a8',1,'Fecha']]],
  ['vermes_3',['verMes',['../class_fecha.html#ab42ccddfc74083d405b55ecd238cd393',1,'Fecha']]],
  ['vermin_4',['verMin',['../class_fecha.html#af10a546982dc738bef0c249357e1a0cf',1,'Fecha']]]
];
