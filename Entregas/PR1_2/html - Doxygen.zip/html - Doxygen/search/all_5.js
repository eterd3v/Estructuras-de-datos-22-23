var searchData=
[
  ['getemail_0',['getEmail',['../class_imagen.html#a426ba97dfee87122d4a3a61b4459ad52',1,'Imagen']]],
  ['getetiquetas_1',['getEtiquetas',['../class_imagen.html#a82bbc35c733345bc38bd26cc32681d22',1,'Imagen']]],
  ['getfecha_2',['getFecha',['../class_imagen.html#a5b1aed37f369896b51765f9c4861dee2',1,'Imagen']]],
  ['getid_3',['getId',['../class_imagen.html#ada12145018eb081a5d58721622e7ee30',1,'Imagen']]],
  ['getnombre_4',['getNombre',['../class_imagen.html#af9a98fdd25386abc59ddf0494d3a911d',1,'Imagen']]],
  ['gettam_5',['getTam',['../class_imagen.html#a6f977059994ec217b3fb5dc47c932a7b',1,'Imagen']]]
];
