var searchData=
[
  ['setemail_0',['setEmail',['../class_imagen.html#a7e6ef70712cfe00999a06594fb6f6d32',1,'Imagen']]],
  ['setetiquetas_1',['setEtiquetas',['../class_imagen.html#a79f0bcba329b03e3e8acf1667d96fee5',1,'Imagen']]],
  ['setfecha_2',['setFecha',['../class_imagen.html#a204a2f9665282a6645271493ea319728',1,'Imagen']]],
  ['setid_3',['setId',['../class_imagen.html#ace76613f7d8c7ae249df5c23b32179b6',1,'Imagen']]],
  ['setnombre_4',['setNombre',['../class_imagen.html#aa97acfda107dd7e13dd0a5447f4eba3d',1,'Imagen']]],
  ['settam_5',['setTam',['../class_imagen.html#a0d83e46f4b087f75aebc89ec653622c2',1,'Imagen']]]
];
