var searchData=
[
  ['imagen_0',['Imagen',['../class_imagen.html#ab2e649aa7a105155c7bfdb846abf0528',1,'Imagen::Imagen()'],['../class_imagen.html#a0eb9e807ebb905392815e6d4899278ba',1,'Imagen::Imagen(const string &amp;id, const string &amp;email, const string &amp;nombre, unsigned int tam, const Fecha &amp;fecha, const string &amp;etiquetas)']]],
  ['insertar_1',['insertar',['../class_v_dinamico.html#a439606ef0ea9abd0ab7836931f50c502',1,'VDinamico']]]
];
